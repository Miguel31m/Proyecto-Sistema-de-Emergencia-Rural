/*
 * PROYECTO: Sistema de Alerta LoRa (433 MHz) con ESP32 + Confirmación Bidireccional (ACK)
 * INTEGRANTES: Jacobo Ospina, Juan Pablo Gonzales, Miguel Ángel Montoya
 * MÓDULO: Nodo Emisor (Botón de Pánico Rural - Sin WiFi, Sin Shield, Directo en Protoboard)
 * FORMATO: Sketch de Arduino IDE (.ino)
 * LÓGICA DE TIEMPOS:
 *   1. Al presionar el pulsador (GPIO 33), se envía la alerta LoRa y el LED ROJO (GPIO 25) dura prendido exactamente 3 segundos.
 *   2. El emisor espera la confirmación de vuelta desde el receptor (enviada justo cuando Telegram recibe el mensaje).
 *   3. Apenas llega la confirmación de Telegram, el LED VERDE (GPIO 26) del emisor se prende exactamente 3 segundos.
 */

#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <WiFi.h>
#include <esp_bt.h>

// ==========================================
// 1. DEFINICIÓN DE PINES HARDWARE (ESP32 30P)
// ==========================================
#define LORA_SCK  18
#define LORA_MISO 19
#define LORA_MOSI 23
#define LORA_SS   5
#define LORA_RST  14
#define LORA_DIO0 2

#define PIN_BOTON      33  // Pulsador conectado entre GPIO 33 y GND (bus negativo protoboard)
#define PIN_LED_ROJO   25  // LED Rojo: Dura 3 segundos prendido al enviar la alerta
#define PIN_LED_VERDE  26  // LED Verde: Dura 3 segundos prendido apenas llega el mensaje a Telegram

// ==========================================
// 2. PARÁMETROS DE RADIOFRECUENCIA LORA
// ==========================================
#define LORA_FREQ 433E6
const byte SYNC_WORD = 0xF3;

const String ID_NODO      = "NODO_VEREDA_01";
const String CLAVE_ALERTA = "SOS_EMERGENCIA_2026";
const String CLAVE_ACK    = "ACK_TELEGRAM_ENVIADO";

unsigned long contadorMensajes = 0;

// Prototipos de funciones
void enviarAlertaYEsperarTelegram();
bool esperarConfirmacionACK(unsigned long tiempoEsperaMs);

void setup() {
  Serial.begin(115200);

  // Apagar WiFi y Bluetooth en el emisor para ahorrar batería
  WiFi.mode(WIFI_OFF);
  btStop();

  pinMode(PIN_BOTON, INPUT_PULLUP);
  pinMode(PIN_LED_ROJO, OUTPUT);
  pinMode(PIN_LED_VERDE, OUTPUT);

  digitalWrite(PIN_LED_ROJO, LOW);
  digitalWrite(PIN_LED_VERDE, LOW);

  Serial.println("=== INICIANDO NODO EMISOR LORA (433 MHz) ===");

  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);

  if (!LoRa.begin(LORA_FREQ)) {
    Serial.println("ERROR: No se detecta el modulo LoRa Ra-01. Revisa los cables en la protoboard!");
    while (1) {
      digitalWrite(PIN_LED_ROJO, !digitalRead(PIN_LED_ROJO));
      delay(200);
    }
  }

  // Configuración de largo alcance rural
  LoRa.setTxPower(20);             // Potencia máxima (20 dBm)
  LoRa.setSpreadingFactor(12);     // SF12: Máximo alcance
  LoRa.setSignalBandwidth(125E3);  // 125 kHz
  LoRa.setCodingRate4(8);          // Corrección de errores 4/8
  LoRa.setSyncWord(SYNC_WORD);
  LoRa.enableCrc();

  Serial.println("Emisor listo. Presiona el pulsador para enviar senal de ayuda.");

  // Destello rápido inicial para comprobar que ambos LEDs están bien conectados
  digitalWrite(PIN_LED_ROJO, HIGH);
  delay(300);
  digitalWrite(PIN_LED_ROJO, LOW);
  digitalWrite(PIN_LED_VERDE, HIGH);
  delay(300);
  digitalWrite(PIN_LED_VERDE, LOW);
}

void loop() {
  // Detectar si se presionó el botón de pánico
  if (digitalRead(PIN_BOTON) == LOW) {
    delay(50); // Filtro antirrebote
    if (digitalRead(PIN_BOTON) == LOW) {
      enviarAlertaYEsperarTelegram();

      // Esperar a que suelten el botón antes de permitir otra alerta
      while (digitalRead(PIN_BOTON) == LOW) {
        delay(10);
      }
    }
  }
  delay(20);
}

void enviarAlertaYEsperarTelegram() {
  contadorMensajes++;
  String paquete = ID_NODO + "|" + CLAVE_ALERTA + "|" + String(contadorMensajes);

  // Asegurar que el LED verde esté apagado al iniciar
  digitalWrite(PIN_LED_VERDE, LOW);

  Serial.print("Enviando senal de ayuda por LoRa: ");
  Serial.println(paquete);

  // 1. Transmitir paquete por LoRa
  LoRa.beginPacket();
  LoRa.print(paquete);
  LoRa.endPacket();

  // 2. Prender LED ROJO durante exactamente 3 segundos (3000 ms) indicando que se envió la alerta
  digitalWrite(PIN_LED_ROJO, HIGH);
  delay(3000);
  digitalWrite(PIN_LED_ROJO, LOW);

  // 3. Esperar confirmación de vuelta desde el receptor (que la manda apenas envía a Telegram)
  // Damos hasta 10 segundos de margen porque enviar por HTTPS a Telegram tarda ~2 a 4 segundos
  Serial.println("Esperando confirmacion de que llego el mensaje a Telegram...");
  bool confirmado = esperarConfirmacionACK(10000);

  if (confirmado) {
    Serial.println("EXITO: El mensaje llego a Telegram! Encendiendo LED VERDE por 3 segundos.");
    // Encender LED VERDE exactamente 3 segundos (3000 ms)
    digitalWrite(PIN_LED_VERDE, HIGH);
    delay(3000);
    digitalWrite(PIN_LED_VERDE, LOW);
  } else {
    Serial.println("AVISO: No se recibio confirmacion desde el receptor. Reintentando envio una vez...");
    // Reintento automático por si se perdió el primer paquete
    LoRa.beginPacket();
    LoRa.print(paquete);
    LoRa.endPacket();

    digitalWrite(PIN_LED_ROJO, HIGH);
    delay(3000);
    digitalWrite(PIN_LED_ROJO, LOW);

    if (esperarConfirmacionACK(10000)) {
      Serial.println("EXITO en reintento: El mensaje llego a Telegram!");
      digitalWrite(PIN_LED_VERDE, HIGH);
      delay(3000);
      digitalWrite(PIN_LED_VERDE, LOW);
    } else {
      Serial.println("ERROR: Sin respuesta de la central receptora.");
      // Parpadeo corto de aviso
      for (int i = 0; i < 4; i++) {
        digitalWrite(PIN_LED_ROJO, HIGH);
        delay(150);
        digitalWrite(PIN_LED_ROJO, LOW);
        delay(150);
      }
    }
  }
}

bool esperarConfirmacionACK(unsigned long tiempoEsperaMs) {
  unsigned long inicio = millis();

  while (millis() - inicio < tiempoEsperaMs) {
    int packetSize = LoRa.parsePacket();
    if (packetSize) {
      String respuesta = "";
      while (LoRa.available()) {
        respuesta += (char)LoRa.read();
      }

      Serial.print("Confirmacion recibida: ");
      Serial.println(respuesta);

      if (respuesta.indexOf(CLAVE_ACK) != -1 && respuesta.indexOf(ID_NODO) != -1) {
        return true;
      }
    }
    delay(10);
  }
  return false;
}
