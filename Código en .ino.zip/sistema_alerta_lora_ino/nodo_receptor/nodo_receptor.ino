/*
 * PROYECTO: Sistema de Alerta LoRa (433 MHz) con ESP32 + Notificación a Telegram
 * INTEGRANTES: Jacobo Ospina, Juan Pablo Gonzales, Miguel Ángel Montoya
 * MÓDULO: Nodo Receptor Central (Con WiFi + Telegram + Buzzer + LED Rojo Titilante 10s + ACK)
 * FORMATO: Sketch de Arduino IDE (.ino)
 * LÓGICA DE FUNCIONAMIENTO:
 *   1. Recibe la señal LoRa desde el emisor.
 *   2. Envía el mensaje "PELIGRO, SE HA ENVIADO UNA SEÑAL DE AYUDA" al grupo de Telegram.
 *   3. Apenas se envía a Telegram, manda la confirmación ACK por LoRa al emisor (para que prenda su LED verde 3s).
 *   4. Activa el Buzzer auditivo y hace titilar un LED ROJO (GPIO 25) durante 10 segundos (10,000 ms) dando a entender una alerta.
 * LIBRERÍAS REQUERIDAS:
 *   1. LoRa (by Sandeep Mistry)
 *   2. UniversalTelegramBot (by Brian Lough)
 *   3. ArduinoJson (by Benoit Blanchon)
 */

#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <ArduinoJson.h>
#include <esp_bt.h>

// ==========================================
// 1. CONFIGURACIÓN DE RED WIFI Y TELEGRAM
// ==========================================
const char* WIFI_SSID     = "TU_RED_WIFI";          // <-- PON AQUÍ EL NOMBRE DE TU WIFI (2.4 GHz)
const char* WIFI_PASSWORD = "TU_CONTRASENA_WIFI";   // <-- PON AQUÍ LA CONTRASEÑA DE TU WIFI

// Credenciales reales configuradas para tu grupo "Central de Emergencias Rural"
#define BOT_TOKEN "8700900678:AAFtuvl45r6hUcS2kBR2Jd6tt4fhQMJm6wI"
#define CHAT_ID   "-1004323066022"

WiFiClientSecure secured_client;
UniversalTelegramBot bot(BOT_TOKEN, secured_client);

// ==========================================
// 2. DEFINICIÓN DE PINES HARDWARE (ESP32 30P)
// ==========================================
#define LORA_SCK  18
#define LORA_MISO 19
#define LORA_MOSI 23
#define LORA_SS   5
#define LORA_RST  14
#define LORA_DIO0 2

#define PIN_BUZZER       26  // Pin hacia el Buzzer (alerta auditiva)
#define PIN_LED_ALERTA   25  // LED Rojo en el receptor: Titila durante 10 segundos al recibir alerta
#define PIN_BTN_SILENCIO 33  // Pulsador opcional para apagar la alerta antes de los 10s (a GND)

// ==========================================
// 3. PARÁMETROS LORA (433 MHz)
// ==========================================
#define LORA_FREQ 433E6
const byte SYNC_WORD = 0xF3;

const String CLAVE_ESPERADA = "SOS_EMERGENCIA_2026";
const String CLAVE_ACK      = "ACK_TELEGRAM_ENVIADO";

bool alarmaActiva = false;
unsigned long tiempoInicioAlarma = 0;
const unsigned long DURACION_ALERTA_MS = 10000; // 10 segundos exactos titilando y sonando
const unsigned long COOLDOWN_TELEGRAM  = 12000; // Evita mensajes duplicados si llega un reintento
unsigned long ultimoEnvioTelegram = 0;

// Prototipos de funciones
void conectarWiFi();
bool enviarAlertaTelegram(String nombreNodo, int rssi, float snr);
void enviarConfirmacionACK(String nombreNodo);
void apagarAlerta();

void setup() {
  Serial.begin(115200);

  // Apagar Bluetooth para liberar memoria RAM para la conexión HTTPS de Telegram
  btStop();

  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED_ALERTA, OUTPUT);
  pinMode(PIN_BTN_SILENCIO, INPUT_PULLUP);

  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_LED_ALERTA, LOW);

  Serial.println("=== INICIANDO NODO RECEPTOR CENTRAL LORA + TELEGRAM ===");

  // 1. Iniciar módulo LoRa Ra-01
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);

  if (!LoRa.begin(LORA_FREQ)) {
    Serial.println("ERROR: No se detecta el modulo LoRa Ra-01. Revisa los cables en la protoboard!");
    while (1) {
      digitalWrite(PIN_LED_ALERTA, !digitalRead(PIN_LED_ALERTA));
      delay(200);
    }
  }

  LoRa.setTxPower(20);             // Potencia máxima para devolver la confirmación al emisor
  LoRa.setSpreadingFactor(12);
  LoRa.setSignalBandwidth(125E3);
  LoRa.setCodingRate4(8);
  LoRa.setSyncWord(SYNC_WORD);
  LoRa.enableCrc();

  // 2. Conectar a WiFi y preparar Telegram
  conectarWiFi();
  secured_client.setInsecure();

  Serial.println("Receptor listo y escuchando senales de auxilio...");
  bot.sendMessage(CHAT_ID, "✅ *Central de Emergencias Rural conectada*\nSistema LoRa 433 MHz listo para recibir alertas.", "Markdown");
}

void loop() {
  // Reconectar WiFi si se cae la señal
  if (WiFi.status() != WL_CONNECTED) {
    conectarWiFi();
  }

  // 1. Revisar si llegó una señal por LoRa
  int packetSize = LoRa.parsePacket();
  if (packetSize) {
    String mensajeRecibido = "";
    while (LoRa.available()) {
      mensajeRecibido += (char)LoRa.read();
    }

    int rssi = LoRa.packetRssi();
    float snr = LoRa.packetSnr();

    Serial.print("Senal recibida: ");
    Serial.print(mensajeRecibido);
    Serial.print(" | Intensidad RSSI: ");
    Serial.print(rssi);
    Serial.println(" dBm");

    // Verificar si es nuestra señal de auxilio
    if (mensajeRecibido.indexOf(CLAVE_ESPERADA) != -1) {
      int separador = mensajeRecibido.indexOf('|');
      String nombreNodo = (separador != -1) ? mensajeRecibido.substring(0, separador) : "NODO_VEREDA_01";

      Serial.println("¡SENAL DE AUXILIO VALIDADA!");

      // PASO A: Encender inmediatamente el LED rojo y el Buzzer mientras se envía a Telegram
      alarmaActiva = true;
      tiempoInicioAlarma = millis();
      digitalWrite(PIN_LED_ALERTA, HIGH);
      digitalWrite(PIN_BUZZER, HIGH);

      // PASO B: Mandar la alerta a Telegram
      bool enviadoTelegram = false;
      if (millis() - ultimoEnvioTelegram > COOLDOWN_TELEGRAM || ultimoEnvioTelegram == 0) {
        enviadoTelegram = enviarAlertaTelegram(nombreNodo, rssi, snr);
        if (enviadoTelegram) {
          ultimoEnvioTelegram = millis();
        }
      } else {
        enviadoTelegram = true; // Ya se había enviado hace pocos segundos
      }

      // PASO C: Apenas llega/se envía el mensaje a Telegram, confirmar al emisor para que prenda su LED VERDE 3s
      if (enviadoTelegram) {
        enviarConfirmacionACK(nombreNodo);
      }

      // Reiniciar el contador de los 10 segundos exactos de alerta titilante a partir de este momento
      tiempoInicioAlarma = millis();
    }
  }

  // 2. Revisar si presionan el botón opcional para apagar la alerta antes de tiempo
  if (digitalRead(PIN_BTN_SILENCIO) == LOW) {
    delay(50);
    if (digitalRead(PIN_BTN_SILENCIO) == LOW) {
      if (alarmaActiva) {
        Serial.println("Alerta apagada manualmente.");
        apagarAlerta();
      }
    }
  }

  // 3. Hacer titilar el LED ROJO y sonar el Buzzer durante 10 segundos (10,000 ms)
  if (alarmaActiva) {
    if (millis() - tiempoInicioAlarma >= DURACION_ALERTA_MS) {
      Serial.println("Fin de los 10 segundos de alerta visual y sonora.");
      apagarAlerta();
    } else {
      // Titileo rápido cada 250 ms (enciende 250 ms, apaga 250 ms) durante los 10 segundos
      unsigned long fase = (millis() / 250) % 2;
      if (fase == 0) {
        digitalWrite(PIN_LED_ALERTA, HIGH);
        digitalWrite(PIN_BUZZER, HIGH);
      } else {
        digitalWrite(PIN_LED_ALERTA, LOW);
        digitalWrite(PIN_BUZZER, LOW);
      }
    }
  }
}

void conectarWiFi() {
  Serial.print("Conectando a WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int intentos = 0;
  while (WiFi.status() != WL_CONNECTED && intentos < 30) {
    delay(500);
    Serial.print(".");
    intentos++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi conectado! IP: " + WiFi.localIP().toString());
  } else {
    Serial.println("\nNo se pudo conectar al WiFi.");
  }
}

bool enviarAlertaTelegram(String nombreNodo, int rssi, float snr) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Sin WiFi: No se pudo enviar el mensaje a Telegram.");
    return false;
  }

  String texto = "🚨 *PELIGRO, SE HA ENVIADO UNA SEÑAL DE AYUDA* 🚨\n\n";
  texto += "📍 *Origen:* " + nombreNodo + "\n";
  texto += "📡 *Calidad de senal LoRa:* " + String(rssi) + " dBm (SNR " + String(snr, 1) + ")\n";
  texto += "⚠️ *Atencion:* Acudir de inmediato a verificar la emergencia.";

  Serial.println("Enviando alerta al grupo de Telegram...");
  bool enviado = bot.sendMessage(CHAT_ID, texto, "Markdown");

  if (enviado) {
    Serial.println("Mensaje enviado a Telegram correctamente!");
    return true;
  } else {
    Serial.println("Fallo al enviar mensaje a Telegram.");
    return false;
  }
}

void enviarConfirmacionACK(String nombreNodo) {
  String paqueteACK = CLAVE_ACK + "|" + nombreNodo;

  Serial.print("Enviando confirmacion al emisor para encender su LED verde por 3s: ");
  Serial.println(paqueteACK);

  // Enviar 2 ráfagas rápidas para asegurar que el emisor las capte
  for (int i = 0; i < 2; i++) {
    LoRa.beginPacket();
    LoRa.print(paqueteACK);
    LoRa.endPacket();
    delay(120);
  }
}

void apagarAlerta() {
  alarmaActiva = false;
  digitalWrite(PIN_LED_ALERTA, LOW);
  digitalWrite(PIN_BUZZER, LOW);
}
