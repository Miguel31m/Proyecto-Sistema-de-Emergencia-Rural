# Proyecto: Sistema de Alerta LoRa (433 MHz) con ESP32 y Telegram (Archivos .ino para Arduino IDE)

**Integrantes:** Jacobo Ospina, Juan Pablo Gonzales, Miguel Ángel Montoya

## Archivos incluidos en este ZIP
- `nodo_emisor/nodo_emisor.ino`: Sketch para Arduino IDE del botón de pánico (LED Rojo 3s al enviar + LED Verde 3s al confirmarse llegada a Telegram).
- `nodo_receptor/nodo_receptor.ino`: Sketch para Arduino IDE de la estación central (Envío a Telegram + Buzzer + LED Rojo titilando 10s).

## Cómo abrirlos en Arduino IDE
1. Descomprime este archivo `.zip` primero en tu computador.
2. Haz doble clic en `nodo_emisor/nodo_emisor.ino` (o ábrelo desde `Archivo -> Abrir` en Arduino IDE) para subirlo al ESP32 Emisor.
3. Haz doble clic en `nodo_receptor/nodo_receptor.ino`, escribe el nombre y contraseña de tu red WiFi (de 2.4 GHz) en las líneas 29 y 30, y súbelo al ESP32 Receptor.
